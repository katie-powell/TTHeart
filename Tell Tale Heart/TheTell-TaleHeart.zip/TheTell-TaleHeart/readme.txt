


  === THE TELL-TALE HEART ===

A game for Global Game Jam 2013

Created by Eric Leventhal
	and Katie Powell

Open Tell-TaleHeart1_27.exe to play.

Controls:
  WASD to move
  Mouse to move flashlight
  Mouse click to check object

Objective:
  Find the beating heart before
the madman finds you.

Special Thanks:
  Isaac Steele for voices,
programming consulting and
immoral support.